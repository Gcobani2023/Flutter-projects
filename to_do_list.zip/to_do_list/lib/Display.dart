
import 'package:flutter/material.dart';

void main(){
  runApp(const MaterialApp());
}
class Display extends StatefulWidget {
  const Display({Key? key}) : super(key: key);
  @override
  State<Display> createState() => _DisplayState();
}
class _DisplayState extends State<Display> {
  String title='';
  String description='';
  String priority='blue';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal,
      //add home icon
      bottomNavigationBar:Icon(Icons.home_filled),
      //center action button
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Display()
              )
          );
        },
        child:  const Icon((Icons.done)),
      ),
      appBar: AppBar(
        title: const Text('Add items') ,
        centerTitle: true,

      ),
      body: Container(
        margin: const EdgeInsets.all(2.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const Text(
                'Title:',
                style: TextStyle(
                    fontSize: 20.0
                )
            ),
            const SizedBox(height: 10.0),
            //#1
            TextField(
              onChanged: (value){
                setState(() {
                  title= value;
                });
              },
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.normal,
                decorationStyle: TextDecorationStyle.solid,
              ),
              decoration: InputDecoration(
                  hintText: 'Enter title',
                  hintStyle: const TextStyle(
                    color: Colors.white,
                    // border: InputBorder.none,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,

                  ),
                  filled: true,
                  fillColor: Colors.grey,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(12.0),
                  )
              ),
            ),
            //#1
            const Text(
                'Description:',
                style: TextStyle(
                    fontSize: 20.0
                )
            ),
            const SizedBox(height: 10.0),

            TextField(
              onChanged: (value){
                setState(() {
                  title= value;

                });
              },
              style: const TextStyle(
                color: Colors.black,
              ),
              decoration: InputDecoration(
                  hintText: 'Enter title',
                  hintStyle: const TextStyle(
                    color: Colors.white,
                    // border: InputBorder.none,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,

                  ),
                  filled: true,
                  fillColor: Colors.grey,
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(12.0),
                  )
              ),
            ),

            //dropdown

            DropdownButton(
              value: priority,
              isExpanded: true,
              items: const[
                DropdownMenuItem(
                    value: 'red',
                    child: Text("red")
                ),
                DropdownMenuItem(
                  value: 'orange',
                  child: Text("orange"),),
                DropdownMenuItem(
                  value: 'blue',
                  child: Text("blue"),)
              ],
              onChanged: (value){},
            ),
            const SizedBox(height: 20.0)
          ],
        ),
      ),
    );
  }
}
