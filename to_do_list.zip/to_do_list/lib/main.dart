import 'package:flutter/material.dart';
import 'package:to_do_list/tings_to_do.dart';
import 'package:to_do_list/Display.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To do list',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'To Do '),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
 // var value1
  bool isChecked = false;
  @override
  Widget build(BuildContext context) {
    List<ThingsToDo> thingstodo =[

      ThingsToDo(
        title: 'Wash a car',
        description: 'I washed a car with muddy water',
        color: Colors.greenAccent,

      ),
      ThingsToDo(
          title: 'Went to store',
          description: 'I went to buy something to eat',
          color: Colors.amberAccent),
      ThingsToDo(
          title: 'Folded clothes',
          description: 'I folded my clothes after',

          color: Colors.purpleAccent)
    ];


    return Scaffold(
        backgroundColor: Colors.teal,
//center action button
floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

        floatingActionButton: FloatingActionButton(
          onPressed: (){
            Navigator.push((context),
                MaterialPageRoute(builder:(context)=> const Display(),
                )
            );
          },
          child: const Icon(Icons.add),
        ),
        appBar: AppBar(

          title: Text(widget.title),
        ),
        body: ListView.builder(

            itemCount: thingstodo.length,
            itemBuilder: (context,index){
              return Padding(padding: EdgeInsets.only(bottom: 4.0),
                child: Card(
                  color: thingstodo[index].color,

                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical:20.0 ,horizontal:20.0 ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,

                          children: [
                            Text(thingstodo[index].title

                            ),
                            Text(thingstodo[index].description)
                          ],
                        ),

                        //const Checkbox(value: value, onChanged: onChanged)


                        ],
                    ),
                  ),
                ) ,
              );
            })
    );
  }}